
import java.util.ArrayList;

public class Main {


    public static void main(String[] args) {

        ArrayList<Person> people = new ArrayList<>();

        // Tilføjer Persons
       // people.add(new Person(100, "Hans Nielsen", "hni@easv.dk"));
       // people.add(new Person(101, "Niels Hansen", "nha@easv.dk"));
       // people.add(new Person(102, "Ib Boesen", "ibo@easv.dk"));


       // Person p2 = new Person(169, "Lars Larsen", "lala@easv.dk");
       // //people.add(p2);

        // Tilføjer Teachers
        people.add(new Teacher(202, "Bent H. Pedersen", "bhp@easv.dk", "bhp", "Programming"));
        people.add(new Teacher(203, "Peder H Bentsen", "phb@easv.dk", "phb", "Software Design"));

        Teacher t1 = new Teacher(203,"JJA", "hah", "hdhdh", "shaud");
        // Tilføjer Students
        Student bo = new Student(205, "Bo Ibsen", "bib@easv.dk", "CS");
        people.add(bo);

        Student bo1 = new Student(207, "Bo Olesen", "bool@easv.dk", "CS");
        people.add(bo1);

        // Tilføjer Student Grades
        bo.addGrade(new GradeInfo(7, "CS"));
        bo.addGrade(new GradeInfo(10, "ITO"));
        bo.addGrade(new GradeInfo(12, "SDE"));


        // Test med PersonManager

        PersonsManager magnus = new PersonsManager();
        //magnus.addPerson(p2);
        magnus.getPerson(102);
        magnus.addTeacher(t1);
        //magnus.addPerson(new Person(200, "LLLLLLL", "hygger"));

        magnus.removePerson(200);

        System.out.println("Get person ID 169_" + magnus.getPerson(200));

        // Note: Vi kan godt få den til at finde navnet på det rigtige ID, men kan ikke tilføje en ny person gennem
        // addPerson. Er ikke helt sikre på hvorfor der er fejl der.
        // Får den ikke printet ud sammen med de andre, men kan i hvertfald også godt fjerne en person.


        System.out.printf("%s%10s%13s%18s%10s%20s%20s%n", "ID", "NAME", "EMAIL", "INITIALS", "MAIN", "EDUCATION", "AVGGRADE","\n");

        for (Person pe : people)
        {
                System.out.printf("%s%n", pe.toString());
        }

        System.out.println("Alle Personer:   " + magnus.getPersons());
        System.out.println("Alle Studerende:   " + magnus.getStudents());
        System.out.println("Alle Lærere:   " + magnus.getTeachers());


        new MainMenu().run();
    }
}
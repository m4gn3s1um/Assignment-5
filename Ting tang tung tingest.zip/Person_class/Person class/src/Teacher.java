public class Teacher extends Person

{
    public String initialise;
    public String main;

    public Teacher(int id, String name, String email, String initialise, String main)
    {

        super(id, name, email);
        this.initialise = initialise;
        this.main = main;

    }

    public String toString()
        {
            return id + " " + name + " " + email + "      " + initialise + "      " + main;
        }

}

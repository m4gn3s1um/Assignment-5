import java.util.ArrayList;
import java.util.List;

public class Student extends Person
{
    private List<GradeInfo> gradeReport = new ArrayList<>();
    private String education;

    public Student(int id, String name, String email, String education) {
        super(id, name, email);
        this.education = education;
    }

    public List<GradeInfo> getGradeReport() {
        return gradeReport;
    }

    public String getEducation() {
        return education;
    }

    public double getAverageGrade(){
        double sum = 0;
        for(GradeInfo g : gradeReport){
            sum += g.getGrade();
        }

        return sum/gradeReport.size();
    }

    public int getGrade(String subject){
        for(GradeInfo g : gradeReport){
            if(g.getSubject().equals(subject))
                return g.getGrade();
        }
        return -100;
    }

    public void addGrade(GradeInfo gradeInfo){
        gradeReport.add(gradeInfo);
    }

    @Override
    public String toString() {
        return super.toString() + "                                           " + education + "           " + getAverageGrade();
    }
}

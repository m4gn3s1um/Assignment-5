import java.util.ArrayList;
import java.util.List;

public class PersonsManager {
    List<Person> people = new ArrayList<>();


    public Person getPerson(int id) {
        for (Person p : people)
            if (p.getId() == id)
                return p;
        return null;
    }




    // Returnerer de forskellige lister der er

    public List<Person> getPersons() {
        return people;
    }

    public List<Teacher> getTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        for (Person p : people)
            if (p instanceof Teacher)
                teachers.add((Teacher) p);

        return teachers;

    }

    public List<Student> getStudents() {
        List<Student> students = new ArrayList<>();
        for (Person p : people)
            if (p instanceof Student)
                students.add((Student) p);

        return students;
    }

    public void addPerson(Person p) {
        for(Person pe : people)
            if(pe.equals(p))
                return;
        people.add(p);

    }

    public void addTeacher(Teacher t) {
       people.add(t);
    }


    public void removePerson(int id) {

        Person gettingRemoved = null;

        for (Person p : people)
            if (p.getId() == id) {
                gettingRemoved = p;
            }
        people.remove(gettingRemoved);
    }

    public String toString(){

        String out ="ID    NAME      EMAIL       INITIALS        MAIN         EDUCATION       AVGGRADE\n";

        for (Person pe : people)
        {
            System.out.println(pe);
        }
        return null;
    }


}
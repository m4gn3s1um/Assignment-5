public class MainMenu extends Menu{

    public MainMenu() {

        super("Min Menu","First option", "Second option");
    }

    @Override
    protected void doAction(int option) {

        if(option == 1)
            System.out.print("You chose 1");
        else if (option == 2)
            System.out.print("You chose 2");
    }
}

public abstract class Person {

    public int id;
    public String name;
    public String email;

    public Person(int id, String name, String email)
    {
        this.id = id;
        this.name = name;
        this.email = email;
    }
//1:08:48
    public String toString()
    {
        return id + " " + name + " " + email;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public boolean equals(Object o) {
      Person otherPerson = (Person) o;
        if(otherPerson.getId()==this.getId())
            return true;

        else return false;
    }

}
